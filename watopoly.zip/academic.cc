#include "academic.h"

Academic::Academic(int ID, std::string name, int costToBuy, 
		           char owner) 
    : Ownable(ID, name, costToBuy, owner) {
    tuition = costToPayUnimprProp(name);    
}

int Academic::amountToPay() {
    if (blockOwned){
        return costToPayUnimprPropBlock(this->getName());
    } else if (this->getImprLevel() == 0){
        return costToPayUnimprProp(this->getName());
    }
    return costToPayImprProp(this->getName(), this->getImprLevel());
}

void Academic::setBlockOwned(bool status){
    blockOwned = status;
}

bool Academic::getBlockOwned(){
    return blockOwned;
}
