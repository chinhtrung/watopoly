#include "Unownable.h"

using namespace std;

Unownable::Unownable(int ID, string name) 
	: Square{ID, name}
{}
